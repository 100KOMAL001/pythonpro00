function greet(){
    alert('this is js file')
}